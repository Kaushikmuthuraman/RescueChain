/**
 * Homepage API Service
 * Public API calls for homepage data
 */

import apiClient from './apiClient';

/**
 * Get homepage statistics
 * @returns {Promise} Homepage stats
 */
export const getHomepageStats = async () => {
    const response = await apiClient.get('/homepage/stats');
    return response.data.stats;
};

/**
 * Get public NGO list
 * @returns {Promise} List of NGOs
 */
export const getPublicNGOs = async () => {
    const response = await apiClient.get('/homepage/ngos');
    return response.data.ngos;
};
